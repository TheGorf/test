"""Lambda@Edge signature validation package."""
