# Design Document

## Overview

This system implements cryptographic signature validation at the AWS CloudFront edge using Lambda@Edge. The Lambda function intercepts viewer requests, extracts a key ID from the URL, retrieves the corresponding cryptographic key from DynamoDB, validates the request signature, and either allows or rejects the request. Successfully validated requests receive an additional verification header before being forwarded to the origin.

### Key Design Decisions

1. **Lambda@Edge Event Type**: Use viewer-request event to validate before CloudFront caching
2. **Key Storage**: DynamoDB for dynamic key management with key ID-based lookups
3. **Signature Algorithms**: Support HMAC-SHA256 (symmetric) and RSA-SHA256 (asymmetric)
4. **Performance**: Implement connection pooling and caching to minimize latency
5. **Error Handling**: Fail closed - reject requests on any validation error

## Architecture

### High-Level Flow

```mermaid
sequenceDiagram
    participant Client
    participant CloudFront
    participant Lambda@Edge
    participant DynamoDB
    participant Origin

    Client->>CloudFront: HTTP Request with Signature
    CloudFront->>Lambda@Edge: Viewer Request Event
    Lambda@Edge->>Lambda@Edge: Extract Key ID from URL
    Lambda@Edge->>DynamoDB: Query Key by ID
    DynamoDB-->>Lambda@Edge: Return Key Data
    Lambda@Edge->>Lambda@Edge: Validate Signature
    alt Signature Valid
        Lambda@Edge->>Lambda@Edge: Add Verification Header
        Lambda@Edge-->>CloudFront: Modified Request
        CloudFront->>Origin: Forward Request
        Origin-->>Client: Response
    else Signature Invalid
        Lambda@Edge-->>CloudFront: 403 Forbidden
        CloudFront-->>Client: 403 Forbidden
    end
```

### Component Architecture

```mermaid
graph TD
    A[Lambda Handler] --> B[Request Parser]
    A --> C[Signature Validator]
    A --> D[Response Builder]
    
    B --> E[Key ID Extractor]
    B --> F[Header Parser]
    B --> G[Payload Builder]
    
    C --> H[Key Retriever]
    C --> I[HMAC Validator]
    C --> J[RSA Validator]
    C --> K[Timestamp Validator]
    
    H --> L[DynamoDB Client]
    
    D --> M[Header Injector]
```

## Components and Interfaces

### 1. Lambda Handler (`lambda_function.py`)

Main entry point for Lambda@Edge function.

```python
def lambda_handler(event, context):
    """
    CloudFront viewer-request event handler
    
    Args:
        event: CloudFront viewer request event
        context: Lambda context object
        
    Returns:
        Modified request or error response
    """
```

**Responsibilities:**
- Parse CloudFront event structure
- Orchestrate validation workflow
- Handle exceptions and return appropriate responses
- Log validation results

### 2. Request Parser (`request_parser.py`)

Extracts and validates request components.

```python
class RequestParser:
    def extract_key_id(self, request) -> str:
        """Extract key ID from URL path or query parameter"""
        
    def extract_signature(self, headers) -> str:
        """Extract signature from X-Signature header"""
        
    def extract_timestamp(self, headers) -> int:
        """Extract timestamp from X-Timestamp header"""
        
    def extract_algorithm(self, headers) -> str:
        """Extract algorithm from X-Algorithm header (default: HMAC-SHA256)"""
        
    def build_signing_payload(self, request) -> bytes:
        """Construct canonical signing payload from request components"""
```

**Key ID Extraction Strategy:**
- Primary: Extract from URL path (e.g., `/api/{key_id}/resource`)
- Fallback: Extract from query parameter (e.g., `?key_id=abc123`)

**Signing Payload Construction:**
```
{HTTP_METHOD}\n
{URI_PATH}\n
{CANONICAL_QUERY_STRING}\n
{TIMESTAMP}\n
{BODY_HASH}
```

### 3. Key Retriever (`key_retriever.py`)

Manages DynamoDB key lookups with caching.

```python
class KeyRetriever:
    def __init__(self, table_name: str):
        """Initialize with DynamoDB table name"""
        
    def get_key(self, key_id: str) -> dict:
        """
        Retrieve key from DynamoDB
        
        Returns:
            {
                'key_id': str,
                'key_value': str,
                'algorithm': str,
                'status': str  # 'active' or 'revoked'
            }
        """
```

**DynamoDB Table Schema:**
```
Table: signature-keys
Partition Key: key_id (String)

Attributes:
- key_id: String (unique identifier)
- key_value: String (base64-encoded key material)
- algorithm: String (HMAC-SHA256 or RSA-SHA256)
- status: String (active or revoked)
- created_at: Number (Unix timestamp)
- updated_at: Number (Unix timestamp)
```

**Caching Strategy:**
- Use Lambda execution context to cache keys between invocations
- Cache TTL: 5 minutes
- Cache invalidation on DynamoDB errors

### 4. Signature Validator (`signature_validator.py`)

Validates cryptographic signatures.

```python
class SignatureValidator:
    def validate(self, signature: str, payload: bytes, key: dict, algorithm: str) -> bool:
        """Main validation entry point"""
        
    def validate_hmac(self, signature: str, payload: bytes, secret: str) -> bool:
        """Validate HMAC-SHA256 signature"""
        
    def validate_rsa(self, signature: str, payload: bytes, public_key: str) -> bool:
        """Validate RSA-SHA256 signature"""
```

**Validation Logic:**
1. Check key status (must be 'active')
2. Verify algorithm matches key configuration
3. Decode signature from base64
4. Compute expected signature
5. Perform constant-time comparison

### 5. Timestamp Validator (`timestamp_validator.py`)

Prevents replay attacks.

```python
class TimestampValidator:
    def __init__(self, max_age_seconds: int = 300):
        """Initialize with maximum allowed age (default 5 minutes)"""
        
    def validate(self, timestamp: int) -> bool:
        """Validate timestamp is within acceptable window"""
```

**Validation Rules:**
- Timestamp must be Unix epoch in seconds
- Timestamp must not be in the future (allow 30s clock skew)
- Timestamp must not be older than 5 minutes

### 6. Response Builder (`response_builder.py`)

Constructs CloudFront responses.

```python
class ResponseBuilder:
    def add_verification_header(self, request: dict, key_id: str) -> dict:
        """Add X-Signature-Verified header to request"""
        
    def build_error_response(self, status_code: int, message: str) -> dict:
        """Build CloudFront error response"""
```

**Verification Header Format:**
```
X-Signature-Verified: validated; timestamp=1234567890; key_id=abc123; algorithm=HMAC-SHA256
```

## Data Models

### CloudFront Event Structure (Input)

```python
{
    'Records': [{
        'cf': {
            'request': {
                'method': 'GET',
                'uri': '/api/abc123/resource',
                'querystring': 'param=value',
                'headers': {
                    'x-signature': [{'value': 'base64_signature'}],
                    'x-timestamp': [{'value': '1234567890'}],
                    'x-algorithm': [{'value': 'HMAC-SHA256'}]
                },
                'body': {
                    'data': 'base64_encoded_body'
                }
            }
        }
    }]
}
```

### DynamoDB Key Record

```python
{
    'key_id': 'abc123',
    'key_value': 'base64_encoded_key_material',
    'algorithm': 'HMAC-SHA256',
    'status': 'active',
    'created_at': 1234567890,
    'updated_at': 1234567890
}
```

### Modified Request (Output)

```python
{
    'method': 'GET',
    'uri': '/api/abc123/resource',
    'querystring': 'param=value',
    'headers': {
        'x-signature': [{'value': 'base64_signature'}],
        'x-timestamp': [{'value': '1234567890'}],
        'x-signature-verified': [{
            'value': 'validated; timestamp=1234567890; key_id=abc123; algorithm=HMAC-SHA256'
        }]
    }
}
```

## Error Handling

### Error Response Matrix

| Condition | Status Code | Response Body |
|-----------|-------------|---------------|
| Missing key ID | 400 | "Missing key ID in request" |
| Missing signature header | 401 | "Missing signature header" |
| Missing timestamp header | 400 | "Missing timestamp header" |
| Invalid timestamp | 401 | "Request timestamp expired" |
| Key not found | 401 | "Invalid key ID" |
| Revoked key | 401 | "Key has been revoked" |
| Invalid signature | 403 | "Signature validation failed" |
| Unsupported algorithm | 400 | "Unsupported algorithm" |
| DynamoDB error | 500 | "Internal server error" |
| Validation exception | 500 | "Internal server error" |

### Logging Strategy

**Success Logs:**
```python
{
    'level': 'INFO',
    'message': 'Signature validated successfully',
    'key_id': 'abc123',
    'algorithm': 'HMAC-SHA256',
    'request_id': 'cloudfront_request_id'
}
```

**Failure Logs:**
```python
{
    'level': 'WARN',
    'message': 'Signature validation failed',
    'key_id': 'abc123',
    'reason': 'Invalid signature',
    'request_id': 'cloudfront_request_id'
}
```

**Error Logs:**
```python
{
    'level': 'ERROR',
    'message': 'DynamoDB query failed',
    'key_id': 'abc123',
    'error': 'exception_message',
    'request_id': 'cloudfront_request_id'
}
```

## Performance Considerations

### Lambda@Edge Constraints

- **Package Size**: Must be under 1MB (compressed)
- **Execution Time**: Must complete within 5 seconds for viewer requests
- **Memory**: Allocate 128MB (minimum for DynamoDB SDK)
- **Timeout**: Set to 5 seconds (maximum for viewer requests)

### Optimization Strategies

1. **Connection Pooling**: Reuse DynamoDB connections across invocations
2. **Key Caching**: Cache retrieved keys in Lambda execution context
3. **Minimal Dependencies**: Use only essential libraries (boto3, cryptography)
4. **Lazy Initialization**: Initialize DynamoDB client on first use
5. **Binary Payload**: Use binary format for signature comparison

### Expected Latency

- Cold start: 200-500ms
- Warm execution with cache hit: 5-20ms
- Warm execution with DynamoDB query: 50-150ms

## Security Considerations

1. **Key Protection**: Keys never logged or exposed in error messages
2. **Constant-Time Comparison**: Prevent timing attacks on signature validation
3. **Replay Protection**: Timestamp validation with 5-minute window
4. **Key Rotation**: Support key status field for revocation
5. **Header Spoofing**: Verification header uses format that clients cannot easily forge
6. **DynamoDB Access**: Lambda execution role has read-only access to keys table

## Testing Strategy

### Unit Tests

- Request parser component tests
- Signature validation algorithm tests
- Timestamp validation tests
- Response builder tests
- Mock DynamoDB interactions

### Integration Tests

- End-to-end signature validation with real DynamoDB
- CloudFront event structure parsing
- Error response generation
- Header injection verification

### Performance Tests

- Cold start latency measurement
- Warm execution latency measurement
- DynamoDB query performance
- Package size validation

### Security Tests

- Invalid signature rejection
- Expired timestamp rejection
- Missing header rejection
- Revoked key rejection
- Timing attack resistance

## Deployment Considerations

### Lambda Configuration

```yaml
Runtime: python3.11
Memory: 128MB
Timeout: 5 seconds
Environment Variables:
  - DYNAMODB_TABLE_NAME: signature-keys
  - DYNAMODB_REGION: us-east-1
  - MAX_TIMESTAMP_AGE: 300
  - LOG_LEVEL: INFO
```

### IAM Permissions

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:Query"
      ],
      "Resource": "arn:aws:dynamodb:*:*:table/signature-keys"
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
```

### CloudFront Distribution Configuration

- Event Type: viewer-request
- Include Body: Yes (for POST/PUT requests)
- Lambda Function ARN: Must be in us-east-1 region

## Dependencies

### Python Libraries

- `boto3`: AWS SDK for DynamoDB access (included in Lambda runtime)
- `cryptography`: For RSA signature validation
- Standard library: `hmac`, `hashlib`, `base64`, `json`, `time`, `re`

### Package Size Optimization

- Use Lambda layer for `cryptography` library if needed
- Strip unnecessary files from deployment package
- Use `pip install --target` with `--no-deps` for minimal installs
