# Project Structure

## Organization

This project is currently in initial setup phase. The folder structure will be documented as the project develops.

## Directory Layout

```
.
└── .kiro/
    └── steering/    # AI assistant steering rules
```

## Conventions

Project conventions will be established as code is added to the repository.
