#!/bin/bash
# Redeploy Lambda function without environment variables for Lambda@Edge compatibility

set -e

echo "=== Redeploying Lambda function without environment variables ==="

# Check if layer ARN exists
if [ ! -f "layer-arn.txt" ]; then
    echo "Error: Layer ARN not found. Run ./create_layer.sh first"
    exit 1
fi

LAYER_ARN=$(cat layer-arn.txt)
echo "Using Layer ARN: $LAYER_ARN"

# Rebuild package with updated config
echo ""
echo "Rebuilding deployment package..."
./build_package_with_layer.sh

# Delete existing function
echo ""
echo "Deleting existing function..."
aws lambda delete-function \
  --function-name signature-validation-edge \
  --region us-east-1 || echo "Function not found, continuing..."

# Wait a moment for deletion to complete
sleep 5

# Get AWS account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Redeploy Lambda function without environment variables
echo ""
echo "Redeploying Lambda function without environment variables..."
aws lambda create-function \
  --function-name signature-validation-edge \
  --runtime python3.11 \
  --role arn:aws:iam::${ACCOUNT_ID}:role/lambda-edge-signature-validation-role \
  --handler lambda_function.lambda_handler \
  --zip-file fileb://build/lambda-edge-signature-validation-with-layer.zip \
  --timeout 5 \
  --memory-size 128 \
  --layers "$LAYER_ARN" \
  --region us-east-1

echo ""
echo "Publishing Lambda version..."
echo "Waiting for function to be active..."
aws lambda wait function-active \
  --function-name signature-validation-edge \
  --region us-east-1

echo "Function is now active. Publishing version..."
VERSION_ARN=$(aws lambda publish-version \
  --function-name signature-validation-edge \
  --region us-east-1 \
  --query FunctionArn --output text)

echo ""
echo "✓ Redeployment complete!"
echo "Lambda Version ARN: $VERSION_ARN"
echo ""
echo "Configuration is now hardcoded in src/config.py:"
echo "- DYNAMODB_TABLE_NAME: signature-keys"
echo "- DYNAMODB_REGION: us-east-1"
echo "- MAX_TIMESTAMP_AGE: 300 seconds"
echo "- LOG_LEVEL: INFO"
echo ""
echo "Next step: Configure CloudFront with this ARN:"
echo "./configure_cloudfront.sh YOUR_DISTRIBUTION_ID $VERSION_ARN"