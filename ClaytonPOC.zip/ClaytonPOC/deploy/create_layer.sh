#!/bin/bash
# Create Lambda Layer with cryptography library

set -e

echo "Creating Lambda Layer with cryptography library..."

# Clean previous build
rm -rf layer-build/
mkdir -p layer-build/python

# Install cryptography library to layer directory
echo "Installing cryptography library..."
pip install cryptography==41.0.7 -t layer-build/python/ \
  --platform manylinux2014_x86_64 \
  --only-binary=:all: \
  --no-deps

# Install cryptography dependencies
pip install cffi pycparser -t layer-build/python/ \
  --platform manylinux2014_x86_64 \
  --only-binary=:all:

# Remove unnecessary files to reduce size
echo "Optimizing layer size..."
cd layer-build/python

# Remove test files and documentation
find . -type d -name "tests" -exec rm -rf {} + 2>/dev/null || true
find . -type d -name "*.dist-info" -exec rm -rf {} + 2>/dev/null || true
find . -name "*.pyc" -delete
find . -name "*.pyo" -delete
find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true

cd ../..

# Create layer zip
echo "Creating layer zip..."
cd layer-build
zip -r9 ../cryptography-layer.zip . -x "*.git*" "*.DS_Store"
cd ..

# Check layer size
LAYER_SIZE=$(du -h cryptography-layer.zip | cut -f1)
echo "Layer size: $LAYER_SIZE"

# Create the layer
echo "Creating Lambda Layer..."
LAYER_ARN=$(aws lambda publish-layer-version \
  --layer-name cryptography-lambda-edge \
  --description "Cryptography library for Lambda@Edge" \
  --zip-file fileb://cryptography-layer.zip \
  --compatible-runtimes python3.11 \
  --region us-east-1 \
  --query LayerVersionArn --output text)

echo "Layer created successfully!"
echo "Layer ARN: $LAYER_ARN"
echo ""
echo "Save this ARN - you'll need it when creating the Lambda function."

# Save ARN to file for reference
echo "$LAYER_ARN" > layer-arn.txt
echo "Layer ARN saved to layer-arn.txt"