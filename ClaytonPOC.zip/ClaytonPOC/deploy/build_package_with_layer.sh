#!/bin/bash
# Build Lambda@Edge deployment package (without cryptography - using layer)

set -e

echo "Building Lambda@Edge deployment package (using layer for cryptography)..."

# Clean previous build
rm -rf build/
mkdir -p build/package

# Copy source files
echo "Copying source files..."
cp -r src/* build/package/

# Create minimal requirements.txt without cryptography
cat > build/requirements-minimal.txt << EOF
# No external dependencies - cryptography provided by layer
# boto3 is provided by Lambda runtime
EOF

echo "Skipping cryptography installation (provided by layer)"

# Remove unnecessary files to reduce package size
echo "Optimizing package size..."
cd build/package

# Remove test files and documentation
find . -name "*.pyc" -delete
find . -name "*.pyo" -delete
find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true

# Create deployment package
echo "Creating deployment zip..."
zip -r9 ../lambda-edge-signature-validation-with-layer.zip . -x "*.git*" "*.DS_Store"

cd ../..

# Check package size
PACKAGE_SIZE=$(du -h build/lambda-edge-signature-validation-with-layer.zip | cut -f1)
PACKAGE_SIZE_BYTES=$(stat -f%z build/lambda-edge-signature-validation-with-layer.zip 2>/dev/null || stat -c%s build/lambda-edge-signature-validation-with-layer.zip)

echo "Package size: $PACKAGE_SIZE ($PACKAGE_SIZE_BYTES bytes)"
echo "Deployment package created: build/lambda-edge-signature-validation-with-layer.zip"

if [ $PACKAGE_SIZE_BYTES -gt 1048576 ]; then
    echo "WARNING: Package size still exceeds 1MB limit for Lambda@Edge viewer requests"
else
    echo "✓ Package size is within Lambda@Edge limits"
fi