#!/bin/bash
# Configure CloudFront distribution with Lambda@Edge function

set -e

if [ $# -ne 2 ]; then
    echo "Usage: $0 <DISTRIBUTION_ID> <LAMBDA_VERSION_ARN>"
    echo ""
    echo "Example:"
    echo "  $0 E1234567890ABC arn:aws:lambda:us-east-1:123456789012:function:signature-validation-edge:1"
    echo ""
    echo "To find your distribution ID:"
    echo "  aws cloudfront list-distributions --query 'DistributionList.Items[*].[Id,DomainName]' --output table"
    exit 1
fi

DISTRIBUTION_ID=$1
LAMBDA_ARN=$2

echo "Configuring CloudFront distribution: $DISTRIBUTION_ID"
echo "Lambda@Edge function ARN: $LAMBDA_ARN"

# Get current distribution configuration and ETag
echo "Getting current distribution configuration..."
aws cloudfront get-distribution-config \
    --id $DISTRIBUTION_ID \
    --query 'DistributionConfig' > temp-distribution-config.json

ETAG=$(aws cloudfront get-distribution-config \
    --id $DISTRIBUTION_ID \
    --query 'ETag' --output text)

echo "Current ETag: $ETAG"

# Create a Python script to modify the distribution config
cat > modify_config.py << 'EOF'
import json
import sys

# Read the distribution config
with open('temp-distribution-config.json', 'r') as f:
    config = json.load(f)

lambda_arn = sys.argv[1]

# Add Lambda@Edge association to default cache behavior
if 'LambdaFunctionAssociations' not in config['DefaultCacheBehavior']:
    config['DefaultCacheBehavior']['LambdaFunctionAssociations'] = {
        'Quantity': 0,
        'Items': []
    }

# Ensure Items key exists
lambda_associations = config['DefaultCacheBehavior']['LambdaFunctionAssociations']
if 'Items' not in lambda_associations:
    lambda_associations['Items'] = []
if 'Quantity' not in lambda_associations:
    lambda_associations['Quantity'] = 0

# Check if our function is already associated
existing_functions = lambda_associations['Items']
function_exists = False

# Check if any existing function matches our function name (ignoring version)
function_base_arn = ':'.join(lambda_arn.split(':')[:-1])  # Remove version number
for item in existing_functions:
    existing_base_arn = ':'.join(item.get('LambdaFunctionARN', '').split(':')[:-1])
    if existing_base_arn == function_base_arn:
        function_exists = True
        # Update existing association with new version
        item['LambdaFunctionARN'] = lambda_arn
        print(f"Updated existing Lambda@Edge association to: {lambda_arn}")
        break

if not function_exists:
    # Add our Lambda@Edge function
    new_association = {
        'LambdaFunctionARN': lambda_arn,
        'EventType': 'viewer-request',
        'IncludeBody': True
    }
    
    lambda_associations['Items'].append(new_association)
    lambda_associations['Quantity'] += 1
    
    print(f"Added new Lambda@Edge association: {lambda_arn}")

# Write the modified config
with open('modified-distribution-config.json', 'w') as f:
    json.dump(config, f, indent=2)

print("Distribution configuration updated")
EOF

# Run the Python script to modify the config
python3 modify_config.py "$LAMBDA_ARN"

# Update the distribution
echo "Updating CloudFront distribution..."
aws cloudfront update-distribution \
    --id $DISTRIBUTION_ID \
    --distribution-config file://modified-distribution-config.json \
    --if-match $ETAG

echo ""
echo "✓ CloudFront distribution updated successfully!"
echo ""
echo "Note: It takes 15-20 minutes for CloudFront changes to propagate globally."
echo ""
echo "You can check the deployment status with:"
echo "  aws cloudfront get-distribution --id $DISTRIBUTION_ID --query 'Distribution.Status'"

# Clean up temporary files
rm -f temp-distribution-config.json modified-distribution-config.json modify_config.py

echo ""
echo "Next steps:"
echo "1. Wait for distribution to deploy (Status: Deployed)"
echo "2. Test signature validation using the sample keys in sample-keys.json"
echo "3. Check CloudWatch Logs in us-east-1 for Lambda@Edge execution logs"