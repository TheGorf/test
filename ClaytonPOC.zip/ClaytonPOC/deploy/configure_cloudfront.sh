#!/bin/bash
# Configure CloudFront distribution with Lambda@Edge function

set -e

if [ $# -ne 2 ]; then
    echo "Usage: $0 <DISTRIBUTION_ID> <LAMBDA_VERSION_ARN>"
    echo ""
    echo "Example:"
    echo "  $0 E1234567890ABC arn:aws:lambda:us-east-1:123456789012:function:signature-validation-edge:1"
    echo ""
    echo "To find your distribution ID:"
    echo "  aws cloudfront list-distributions --query 'DistributionList.Items[*].[Id,DomainName]' --output table"
    exit 1
fi

DISTRIBUTION_ID=$1
LAMBDA_ARN=$2

echo "Configuring CloudFront distribution: $DISTRIBUTION_ID"
echo "Lambda@Edge function ARN: $LAMBDA_ARN"

# Get current distribution configuration and ETag
echo "Getting current distribution configuration..."
aws cloudfront get-distribution-config \
    --id $DISTRIBUTION_ID \
    --query 'DistributionConfig' > temp-distribution-config.json

ETAG=$(aws cloudfront get-distribution-config \
    --id $DISTRIBUTION_ID \
    --query 'ETag' --output text)

echo "Current ETag: $ETAG"

# Create a Python script to modify the distribution config
cat > modify_config.py << 'EOF'
import json
import sys

# Read the distribution config
with open('temp-distribution-config.json', 'r') as f:
    config = json.load(f)

lambda_arn = sys.argv[1]

# Add Lambda@Edge association to default cache behavior
if 'LambdaFunctionAssociations' not in config['DefaultCacheBehavior']:
    config['DefaultCacheBehavior']['LambdaFunctionAssociations'] = {
        'Quantity': 0,
        'Items': []
    }

# Check if our function is already associated
existing_functions = config['DefaultCacheBehavior']['LambdaFunctionAssociations']['Items']
function_exists = any(item.get('LambdaFunctionARN', '').startswith(lambda_arn.split(':')[0:6]) for item in existing_functions)

if not function_exists:
    # Add our Lambda@Edge function
    new_association = {
        'LambdaFunctionARN': lambda_arn,
        'EventType': 'viewer-request',
        'IncludeBody': True
    }
    
    config['DefaultCacheBehavior']['LambdaFunctionAssociations']['Items'].append(new_association)
    config['DefaultCacheBehavior']['LambdaFunctionAssociations']['Quantity'] += 1
    
    print(f"Added Lambda@Edge association: {lambda_arn}")
else:
    print("Lambda@Edge function already associated with this distribution")

# Write the modified config
with open('modified-distribution-config.json', 'w') as f:
    json.dump(config, f, indent=2)

print("Distribution configuration updated")
EOF

# Run the Python script to modify the config
python3 modify_config.py "$LAMBDA_ARN"

# Update the distribution
echo "Updating CloudFront distribution..."
aws cloudfront update-distribution \
    --id $DISTRIBUTION_ID \
    --distribution-config file://modified-distribution-config.json \
    --if-match $ETAG

echo ""
echo "✓ CloudFront distribution updated successfully!"
echo ""
echo "Note: It takes 15-20 minutes for CloudFront changes to propagate globally."
echo ""
echo "You can check the deployment status with:"
echo "  aws cloudfront get-distribution --id $DISTRIBUTION_ID --query 'Distribution.Status'"

# Clean up temporary files
rm -f temp-distribution-config.json modified-distribution-config.json modify_config.py

echo ""
echo "Next steps:"
echo "1. Wait for distribution to deploy (Status: Deployed)"
echo "2. Test signature validation using the sample keys in sample-keys.json"
echo "3. Check CloudWatch Logs in us-east-1 for Lambda@Edge execution logs"