#!/bin/bash
# Complete deployment script using Lambda Layer

set -e

echo "=== Lambda@Edge Deployment with Layer ==="

# Check if layer ARN exists
if [ ! -f "layer-arn.txt" ]; then
    echo "Layer ARN not found. Creating layer first..."
    ./create_layer.sh
fi

LAYER_ARN=$(cat layer-arn.txt)
echo "Using Layer ARN: $LAYER_ARN"

# Build package without cryptography
echo ""
echo "Building deployment package..."
./build_package_with_layer.sh

# Get AWS account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Deploy Lambda function with layer
echo ""
echo "Deploying Lambda function with layer..."
aws lambda create-function \
  --function-name signature-validation-edge \
  --runtime python3.11 \
  --role arn:aws:iam::${ACCOUNT_ID}:role/lambda-edge-signature-validation-role \
  --handler lambda_function.lambda_handler \
  --zip-file fileb://build/lambda-edge-signature-validation-with-layer.zip \
  --timeout 5 \
  --memory-size 128 \
  --layers "$LAYER_ARN" \
  --region us-east-1

echo ""
echo "Publishing Lambda version..."
VERSION_ARN=$(aws lambda publish-version \
  --function-name signature-validation-edge \
  --region us-east-1 \
  --query FunctionArn --output text)

echo ""
echo "✓ Deployment complete!"
echo "Lambda Version ARN: $VERSION_ARN"
echo ""
echo "Next steps:"
echo "1. Configure your CloudFront distribution to use this Lambda@Edge function"
echo "2. Use this ARN in your CloudFront Lambda association: $VERSION_ARN"
echo "3. Test with the sample keys in sample-keys.json"